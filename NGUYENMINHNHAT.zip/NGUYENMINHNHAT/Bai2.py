N=int(input("Nhap vao 1 nam bat ki: "))
if (N %400==0) or (N %4==0) or (N % 100==0):
    print('Nam nhuan')
else:
    print('khong phai nam nhuan')