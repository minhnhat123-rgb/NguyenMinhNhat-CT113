N=float(input('nhap nhiet do: '))
if N > 30:
    print('thoi tiet nong')
elif N < 20:
    print('thoi tiet lanh')
else:
    print('thoi tiet de chiu')