A=input('Nhap mat khau : ')
B=input('xac nhan lai mat khau: ')
if A != B:
    print('Mat khau khong giong nhau')
else:
    print('da doi mat khau thanh cong')