N=float(input('Nhap so km da di: '))
if N <=1:
    T= N*7000
elif N <= 5:
    T= 7000+(N-1)*6500
else:
    T=7000+4*6500+( N-5)*6000
print('so tien can phai tra la: ',T)